from Web_Scrapper import Web_Scrapper
from Visualized_Location_Data import Visualized_Location_Data
import requests
import json

class Booking_Scrapper(Web_Scrapper):

    def __init__(self):
        super().__init__()
        self.visualized_data = Visualized_Location_Data()
        self.data_dict = {}

    def getSearchData(self, location, end_location, checkin_date, checkout_date, adults_number):
        self.location = location
        self.checkin_date = checkin_date
        self.checkout_date = checkout_date
        self.adults_number = adults_number

    def search_hotels(self):
        search_location_url = "https://booking-com.p.rapidapi.com/v1/hotels/locations"

        location_querystring = {
            "name": self.location,
            "locale": "en-gb"
        }

        location_headers = {
            'x-rapidapi-host': "booking-com.p.rapidapi.com",
            'x-rapidapi-key': "1749e36fe8mshfb235206840a14ep1c7d0ajsne1ec4bf8b049"  # Replace with your actual RapidAPI key
        }

        response = requests.get(search_location_url, headers=location_headers, params=location_querystring)
        search_location_response = response.json()

        if not search_location_response:
            print("No location results found.")
            return

        dest_id = None
        for list_result in search_location_response:
            if 'dest_id' in list_result:
                dest_id = list_result['dest_id']
                break

        if not dest_id:
            print("No valid destination ID found.")
            return

        search_hotels_url = "https://booking-com.p.rapidapi.com/v1/hotels/search"

        search_hotels_querystring = {
            "checkout_date": self.checkout_date,
            "order_by": "popularity",
            "filter_by_currency": "AED",
            "include_adjacency": "true",
            "room_number": "1",
            "dest_id": dest_id,
            "dest_type": "city",
            "adults_number": self.adults_number,
            "page_number": "0",
            "checkin_date": self.checkin_date,
            "locale": "en-gb",
            "units": "metric",
        }

        search_hotel_headers = {
            'x-rapidapi-host': "booking-com.p.rapidapi.com",
            'x-rapidapi-key': "1749e36fe8mshfb235206840a14ep1c7d0ajsne1ec4bf8b049"  # Replace with your actual RapidAPI key
        }

        response = requests.get(search_hotels_url, headers=search_hotel_headers, params=search_hotels_querystring)
        search_hotel_response = response.json()

        # Save the response to a file
        with open("search_hotel_response.json", "w") as outfile:
            json.dump(search_hotel_response, outfile, indent=4)
        print("Response saved to search_flight_response.json")
        with open("search_hotel_response.json") as outfile:
            self.data_dict = json.load(outfile)
            self.visualized_data.load_json_data(self.data_dict)
            self.visualized_data.getScrapedHotelData()
