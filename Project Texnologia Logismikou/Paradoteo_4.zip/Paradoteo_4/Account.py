from typing import Any


class Account:
    def __init__(self,username,password,email,phonenumber):
        self.username = username
        self.password = password
        self.email = email
        self.phonenumber = phonenumber

    def get_username(self):
        return self.username
    
    def get_password(self):
        return self.password