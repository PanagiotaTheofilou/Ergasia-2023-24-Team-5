class Web_Statistics:
    def __init__(self, json_data=None):
        if json_data:
            self.data = json_data
        else:
            self.data = {}

    def load_json_data(self, json_data):
        self.data = json_data

    def get_web_stats(self):
        return self.data
        