README

To run the program some changes must be made in the pyvenv.cfg located in: Paradoteo_4\.venv
If the file gets unzipped on the  Desktop then replace the User name in the path as shown below:

Replace ~USER_NAME~ with the  User name of your computer (Check all the paths below)

home = C:\Users\~USER_NAME~\AppData\Local\Programs\Python\Python312
include-system-site-packages = false
version = 3.12.4
executable = C:\Users\~USER_NAME~\AppData\Local\Programs\Python\Python312\python.exe
command = C:\Users\~USER_NAME~\AppData\Local\Programs\Python\Python312\python.exe -m venv c:\Users\~USER_NAME~\Desktop\Paradoteo_4\.venv


Also, the webscrapers use APIS from rapidapi.com with a limited amount of requests 