from abc import ABC, abstractmethod

class Web_Scrapper(ABC):

    def __init__(self):
        self.location = None
        self.checkin_date = None
        self.checkout_date = None
        self.adults_number = None

    def get_SearchData(self, location,end_location, checkin_date, checkout_date, adults_number):
        pass

    def search_hotels(self):
        pass

