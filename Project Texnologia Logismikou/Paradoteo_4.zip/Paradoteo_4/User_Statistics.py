from Visualized_Stats import Visualized_Stats

class User_Statistics:
    def __init__(self) -> None:
        self.visualize = Visualized_Stats()
        self.user_stats = {}

    def update_user_stats(self,location):
        if location in self.user_stats:
            self.user_stats[location] += 1
        else:
            self.user_stats[location] = 1

    def requestUserStats(self):
        self.visualize.visualize_user_stats(self.user_stats)