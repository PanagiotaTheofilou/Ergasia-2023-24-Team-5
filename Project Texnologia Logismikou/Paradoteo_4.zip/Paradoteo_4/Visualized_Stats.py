class Visualized_Stats:
    def __init__(self) -> None:
        pass

    def visualize_user_stats(self,data):
        for location, count in data.items():
            print(f"Location: {location}, Count: {count}")
