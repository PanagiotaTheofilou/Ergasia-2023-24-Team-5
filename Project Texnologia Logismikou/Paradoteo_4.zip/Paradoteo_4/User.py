from Search import Search

class User:
    def __init__(self):
        self.user_search = Search()
        
    def SearchDisplay(self):
        self.user_search.search_input()


