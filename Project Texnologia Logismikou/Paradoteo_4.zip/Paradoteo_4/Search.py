from Booking_Scrapper import Booking_Scrapper
from SkyScanner_Scrapper import SkyScanner_Scrapper
from User_Statistics import User_Statistics

class Search:
    def __init__(self):
        self.booking_search = Booking_Scrapper()
        self.skyscanner_search = SkyScanner_Scrapper()
        self.stats = User_Statistics()

    def search_input(self):
        location = input("Enter the start location: ")
        end_location = input("Enter the target location (e.g., city name): ")
        checkin_date = input("Enter the check-in date (YYYY-MM-DD): ")
        checkout_date = input("Enter the check-out date (YYYY-MM-DD): ")
        adults_number = int(input("Enter the number of adults: "))

        self.stats.update_user_stats(location)

        self.perform_hotel_search(location,end_location,checkin_date,checkout_date,adults_number)       

    def perform_hotel_search(self, location,end_location, checkin_date, checkout_date, adults_number):
        self.booking_search.getSearchData(location, end_location, checkin_date, checkout_date, adults_number)
        self.booking_search.search_hotels()
        self.skyscanner_search.getSearchData(location,end_location,checkin_date,checkout_date,adults_number)
        self.skyscanner_search.search_hotels()

