from Account import Account
from Web_Statistics import Web_Statistics
from User_Statistics import User_Statistics

class Employee:
    def __init__(self,account):
        self.account = account
        self.web_stats = Web_Statistics()
        self.user_stats = User_Statistics()

    #def newAccount(self,account):
     #   self.account = account

    def login(self):
        username = input("Enter your username: ")
        while username != self.account.get_username():
            username = input("Wrong username :") 

        password = input("Enter your password: ")
        while password != self.account.get_password():
            password = input("Wrong password :")

    def Employee_Interface(self,web_stats1,web_stats2):
        print("~~~~~~~~ MENU ~~~~~~~~")
        print("1.User's choice!")
        choice = input("Choice(1,2 or 3): ")
        if choice == '1':
            stats = self.user_stats.requestUserStats()
        else: 
            return 0
            