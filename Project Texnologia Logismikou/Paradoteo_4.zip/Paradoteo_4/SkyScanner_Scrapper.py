from Web_Scrapper import Web_Scrapper
from Visualized_Location_Data import Visualized_Location_Data
import requests
import json

class SkyScanner_Scrapper:
    def __init__(self):
        super().__init__()
        self.visualized_data = Visualized_Location_Data()
        self.end_location = None
        self.data_dict = {}

    def getSearchData(self, location, end_location, checkin_date, checkout_date, adults_number):
        self.location = location
        self.end_location = end_location
        self.checkin_date = checkin_date
        self.checkout_date = checkout_date
        self.adults_number = adults_number

    def search_hotels(self):
        search_location_url = "https://sky-scanner3.p.rapidapi.com/flights/auto-complete"

        location_querystring = {
            "query": self.location
        }

        location_headers = {
            "x-rapidapi-key": "1749e36fe8mshfb235206840a14ep1c7d0ajsne1ec4bf8b049",
            "x-rapidapi-host": "sky-scanner3.p.rapidapi.com"
        }

        response = requests.get(search_location_url, headers=location_headers, params=location_querystring)
        search_location_response = response.json()

        if not search_location_response:
            print("No start location results found.")
            return

        # Extract the 'skyId' from the first 'relevantFlightParams'
        start_sky_id = search_location_response['data'][0]['navigation']['relevantFlightParams']['skyId']

        # Print the extracted skyId
        print("Start SkyId:", start_sky_id)

        location_querystring = {
            "query": self.end_location
        }

        response = requests.get(search_location_url, headers=location_headers, params=location_querystring)
        search_location_response = response.json()

        if not search_location_response:
            print("No end location results found.")
            return

        # Extract the 'skyId' from the first 'relevantFlightParams'
        end_sky_id = search_location_response['data'][0]['navigation']['relevantFlightParams']['skyId']

        # Print the extracted skyId
        print("End SkyId:", end_sky_id)


        search_flights_url = "https://sky-scanner3.p.rapidapi.com/flights/search-roundtrip"

        search_flights_querystring = {
            "fromEntityId": start_sky_id,
            "toEntityId": end_sky_id,
            "departDate": self.checkin_date,
            "returnDate": self.checkout_date
        }

        search_flights_headers = {
            "x-rapidapi-key": "1749e36fe8mshfb235206840a14ep1c7d0ajsne1ec4bf8b049",
            "x-rapidapi-host": "sky-scanner3.p.rapidapi.com"
        }

        response = requests.get(search_flights_url, headers=search_flights_headers, params=search_flights_querystring)
        search_flight_response = response.json()

        # Save the response to a file
        with open("search_flight_response.json", "w") as outfile:
            json.dump(search_flight_response, outfile, indent=4)
        print("Response saved to search_flight_response.json")

        with open("search_flight_response.json") as outfile:
            self.data_dict = json.load(outfile)
            self.visualized_data.load_json_data(self.data_dict)
            self.visualized_data.getScrapedFlightData()