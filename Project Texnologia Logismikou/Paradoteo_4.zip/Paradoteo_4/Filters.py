# Filters.py

class Filters:
    def apply_filter_hotels(self, data):
        filter_type = input("What type of filter (Price range, Ascending Order, or Descending Order): ").strip().lower()

        if filter_type == "price range":
            max_price = int(input("Enter the maximum price: "))
            print("~~~~~~~~ FILTERED DATA ~~~~~~~~")
            for hotel in data:
                price = hotel.get("min_total_price", "N/A")
                if int(price) <= max_price:
                    name = hotel.get("hotel_name")
                    address = hotel.get("address", 'N/A')
                    print(f"Hotel: {name}\nAddress: {address}\nPrice: {price}\n")

        elif filter_type == "ascending order":
            print("~~~~~~~~ FILTERED DATA ~~~~~~~~")
            sorted_data = sorted(data, key=lambda x: int(x.get("min_total_price", "0")))
            for hotel in sorted_data:
                name = hotel.get("hotel_name")
                address = hotel.get("address", 'N/A')
                price = hotel.get("min_total_price", "N/A")
                print(f"Hotel: {name}\nAddress: {address}\nPrice: {price}\n")

        elif filter_type == "descending order":
            print("~~~~~~~~ FILTERED DATA ~~~~~~~~")
            sorted_data = sorted(data, key=lambda x: int(x.get("min_total_price", "0")), reverse=True)
            for hotel in sorted_data:
                name = hotel.get("hotel_name")
                address = hotel.get("address", 'N/A')
                price = hotel.get("min_total_price", "N/A")
                print(f"Hotel: {name}\nAddress: {address}\nPrice: {price}\n")

        else:
            print("Invalid filter type. No changes applied.")