from Account import Account
from Employee import Employee

class Admin:
    def __init__(self):
        self.accounts = []

    def createAccount(self):
        print("~~~~~~~~ New Account ~~~~~~~~")
        username = input("Enter the username: ")
        password = input("Enter the password: ")
        email = input("Enter the email: ")
        phonenumber = input("Enter the phonenumber: ")
        new_account = Account(username,password,email,phonenumber)
        self.accounts.append(new_account)
        new_employee = Employee(new_account)

        return new_employee
