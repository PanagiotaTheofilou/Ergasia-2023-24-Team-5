from User import User
from Employee import Employee
from Account import Account
from Admin import Admin
from Web_Statistics import Web_Statistics

def main():
    user1 = User()
    admin1 = Admin()
    employee1 = admin1.createAccount()

    person = input("Login as a user or as an employee(1.User or 2.Employee or 3.Exit): ")
    while person != '3':
        if person == '1':
            user1.SearchDisplay()
            exit = input("Press 0 if you want to exit or 1 if you want to continue for another search:")
            while exit != '0' :
                user1.SearchDisplay()
        elif person == '2':
            employee1.login()
            employee1.Employee_Interface()
        person = input("Login as a user or as an employee(1.User or 2.Employee or 3.Exit): ")
    

if __name__ == "__main__":
    main()