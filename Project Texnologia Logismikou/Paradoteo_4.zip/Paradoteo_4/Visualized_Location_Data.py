from Filters import Filters
import json

class Visualized_Location_Data:
    def __init__(self, json_data=None):
        self.filter = Filters()
        if json_data:
            self.data = json_data
        else:
            self.data = {}

    def load_json_data(self, json_data):
        self.data = json_data

    def getScrapedHotelData(self):
        hotels = self.data.get("result", [])
        for hotel in hotels:
            print("Printing")
            name = hotel.get("hotel_name")
            address = hotel.get("address", "N/A")
            price = hotel.get("min_total_price", "N/A")

            print(f"Hotel Name: {name}")
            print(f"Address: {address}")
            print(f"Price: {price}")
            print("----------------------")

        filter = input("Do you want to apply filters(True or False): ").strip().lower() == 'true'
        if filter:
            self.filter.apply_filter_hotels(hotels)
        elif not filter:
            return 0

    def getScrapedFlightData(self):
        results = []

        for itinerary in self.data['data']['itineraries']:
            leg = itinerary['legs'][0]  # Only take the first leg
            departure_airport = leg['origin']['name']
            departure_airport_code = leg['origin']['displayCode']
            destination_airport = leg['destination']['name']
            destination_airport_code = leg['destination']['displayCode']
            departure_time = leg['departure']
            arrival_time = leg['arrival']
            stops = leg['stopCount']
            price = itinerary['price']['formatted']
            flight_duration_minutes = leg['durationInMinutes']
            carrier_name = leg['carriers']['marketing'][0]['name']
            
            results.append({
                "departure_airport": departure_airport,
                "departure_airport_code": departure_airport_code,
                "destination_airport": destination_airport,
                "destination_airport_code": destination_airport_code,
                "departure_time": departure_time,
                "arrival_time": arrival_time,
                "stops": stops,
                "price": price,
                "flight_duration_minutes": flight_duration_minutes,
                "carrier_name": carrier_name
            })

        # Print the details of the first 10 flights
        print("~~~~~~~~ FIRST 10 FLIGHT RESULTS ~~~~~~~~")
        for idx, result in enumerate(results[:10], start=1):
            print(f"Flight {idx}:")
            print(f"Departure Airport: {result['departure_airport']} ({result['departure_airport_code']})")
            print(f"Destination Airport: {result['destination_airport']} ({result['destination_airport_code']})")
            print(f"Departure Time: {result['departure_time']}")
            print(f"Arrival Time: {result['arrival_time']}")
            print(f"Stops: {result['stops']}")
            print(f"Price: {result['price']}")
            print(f"Flight Duration: {result['flight_duration_minutes']} minutes")
            print(f"Carrier: {result['carrier_name']}")
            print("-" * 40)  # Separator for readability

        # Ask user if they want to apply filters
        filter_choice = input("Do you want to apply filters (True or False): ").strip().lower() == 'true'
        if filter_choice:
            self.filter.apply_filter_flights(results)  # Apply filters to the first 10 flights
        elif not filter_choice:
            return 0